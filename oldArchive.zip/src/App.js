import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import LandingPage from "./pages/LandingPage";
import RulesPage from "./pages/RulesPage";
import GamePage from "./pages/GamePage";

import { ParamProvider } from "./contexts/ParamContext";
import { ThemeProvider } from "./contexts/ThemeContext";

function App() {
  return (
    <ParamProvider>
      <ThemeProvider>
        <Router>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/rules" element={<RulesPage />} />
            <Route path="/game" element={<GamePage />} />
          </Routes>
        </Router>
      </ThemeProvider>
    </ParamProvider>
  );
}

export default App;
