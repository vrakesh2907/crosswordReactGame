import React, { createContext, useEffect, useState } from "react";

export const ParamContext = createContext({
  otp: null,
  role: null,
});

export function ParamProvider({ children }) {
  const [otp, setOtp] = useState(null);
  const [role, setRole] = useState(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);

    const otpParam = params.get("otp");
    const roleParam = params.get("role");

    setOtp(otpParam);
    setRole(roleParam);
  }, []);

  return (
    <ParamContext.Provider value={{ otp, role }}>
      {children}
    </ParamContext.Provider>
  );
}
