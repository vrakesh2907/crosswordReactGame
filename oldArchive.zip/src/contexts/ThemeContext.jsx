import React, { createContext, useEffect, useState } from "react";

export const ThemeContext = createContext({
  theme: null,
  session: null,
  loading: true,
  error: null,
});

const sessionId = process.env.REACT_APP_SESSION_ID;
const organizationId = process.env.REACT_APP_ORG_ID;

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function loadTheme() {
      try {
        const url =
          `https://staging-games.extramileplay.com/crossword_new/admin/API/getThemeData.php?sessionId=${sessionId}&organizationId=${organizationId}`;

        const res = await fetch(url);
        const data = await res.json();

        // Put user/session info separately for use in submit API later
        setSession({
          userId: data.userId,
          sessionId: data.sessionId,
          organizationId: data.organizationId,
          gameId: data.gameId,
          roles: data.roles,
          token: data.token,
          email: data.email,
        });

        setTheme(data);
      } catch (err) {
        console.error("Theme load error:", err);
        setError("Failed to load theme data");
      }

      setLoading(false);
    }

    loadTheme();
  }, []);

  return (
    <ThemeContext.Provider value={{ theme, session, loading, error }}>
      {children}
    </ThemeContext.Provider>
  );
}
