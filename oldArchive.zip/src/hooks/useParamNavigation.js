import { useNavigate } from "react-router-dom";
import { useContext } from "react";
import { ParamContext } from "../contexts/ParamContext";

export default function useParamNavigation() {
  const navigate = useNavigate();
  const { otp, role } = useContext(ParamContext);

  return (path) => {
    if (otp && role) {
      navigate(`${path}?otp=${otp}&role=${role}`);
    } else {
      navigate(path);
    }
  };
}
