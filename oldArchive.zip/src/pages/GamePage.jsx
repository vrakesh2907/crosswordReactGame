/* eslint-disable */
import React, { useContext, useEffect, useMemo, useRef, useState } from "react";
import Crossword from "@jaredreisinger/react-crossword";
import { ThemeContext } from "../contexts/ThemeContext";
import { layoutToCrossword } from "../utils/layoutAdapter";
import { useNavigate } from "react-router-dom";

export default function SmartCrosswordPage() {
  const { theme, loading, error } = useContext(ThemeContext);
  const [cwData, setCwData] = useState(null);

  
  const [score, setScore] = useState(0);
  const [gameResult, setGameResult] = useState(null); 
  const [showPopup, setShowPopup] = useState(false);

 
  const [timerSec, setTimerSec] = useState(0);
  const timerRef = useRef(null);

  const navigate = useNavigate();


  const correctnessRef = useRef({}); 
  const scoredWordsRef = useRef({}); 
  const isMountedRef = useRef(false);


  const pointsPerWord = useMemo(() => {
    if (!theme) return 5;
    const p = Number(theme.points);
    return Number.isFinite(p) && p > 0 ? p : 5;
  }, [theme]);

  const crosswordData = useMemo(() => {
    return cwData ? { across: cwData.across, down: cwData.down } : null;
  }, [cwData]);


  useEffect(() => {
    if (!theme || !theme.questions_and_answers) return;
    const qa = theme.questions_and_answers.map((q) => ({
      question: q.question,
      answer: q.answer,
    }));
    const data = layoutToCrossword(qa);
    setCwData(data);
  }, [theme]);

 
  useEffect(() => {
    if (!cwData) return;
  
    correctnessRef.current = {};
    scoredWordsRef.current = {};
    setScore(0);
  }, [cwData]);


  useEffect(() => {
    if (!theme) return;
    if (theme.use_timeout) {
      const t = theme.timer || "05:00";
      const [m, s] = t.split(":").map((x) => Number(x) || 0);
      setTimerSec(m * 60 + s);
    } else {
      setTimerSec(0);
    }
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, [theme, cwData]);

  
  useEffect(() => {
    if (!theme || !cwData) return;
    if (gameResult) return;

    if (timerRef.current) clearInterval(timerRef.current);

    timerRef.current = setInterval(() => {
      setTimerSec((prev) => {
        if (theme.use_timeout) {
          const next = prev - 1;
          if (next <= 0) {
            clearInterval(timerRef.current);
            timerRef.current = null;
           
            checkWordsAndScore();
            handleEndGame("timeout");
            return 0;
          }
          return next;
        } else {
          return prev + 1;
        }
      });
    }, 1000);

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
   
  }, [theme, cwData, gameResult]);

  const formatTime = (sec) => {
    const m = Math.floor(sec / 60)
      .toString()
      .padStart(2, "0");
    const s = (sec % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  
  const getCellsForEntry = (entry, dir) => {
  
    if (!entry) return [];
    if (Array.isArray(entry.cells) && entry.cells.length > 0) {
      return entry.cells.map((c) => ({
        row: Number(c.row),
        col: Number(c.col),
      }));
    }
    if (
      entry.row !== undefined &&
      entry.col !== undefined &&
      typeof entry.answer === "string"
    ) {
      const r = Number(entry.row);
      const c = Number(entry.col);
      const ans = String(entry.answer);
      const out = [];
      for (let i = 0; i < ans.length; i++) {
        out.push({
          row: dir === "across" ? r : r + i,
          col: dir === "across" ? c + i : c,
        });
      }
      return out;
    }
   
    if (entry.answer && cwData && cwData.grid && cwData.expected) {
      const len = String(entry.answer).length;
      for (let r = 0; r < cwData.grid.length; r++) {
        for (let c = 0; c < cwData.grid[0].length; c++) {
         
          let ok = true;
          const cells = [];
          for (let i = 0; i < len; i++) {
            const rr = dir === "across" ? r : r + i;
            const cc = dir === "across" ? c + i : c;
            if (
              rr < 0 ||
              cc < 0 ||
              rr >= cwData.grid.length ||
              cc >= cwData.grid[0].length ||
              cwData.grid[rr][cc] == null
            ) {
              ok = false;
              break;
            }
            cells.push({ row: rr, col: cc });
          }
          if (ok && cells.length === len) return cells;
        }
      }
    }
    return [];
  };

 
  const checkWordsAndScore = () => {
    if (!cwData) return;

    const dirs = ["across", "down"];
    let mappedWordCount = 0;
    let allCompleted = true;

    dirs.forEach((dir) => {
      const entries = cwData[dir] || {};
      Object.entries(entries).forEach(([num, entry]) => {
        const wordKey = `${dir}-${num}`;
        const cells = getCellsForEntry(entry, dir);
        if (!cells || cells.length === 0) {
         
          return;
        }
        mappedWordCount++;

        const isComplete = cells.every((cell) => {
          const k = `${cell.row}-${cell.col}`;
          return correctnessRef.current[k] === true;
        });

        if (isComplete) {
          if (!scoredWordsRef.current[wordKey]) {
            scoredWordsRef.current[wordKey] = true;
            setScore((s) => s + pointsPerWord);
          }
        } else {
          allCompleted = false;
        }
      });
    });

    
    if (mappedWordCount > 0 && allCompleted) {
      handleEndGame("completed");
    }
  };

  
  const handleCellChange = (row, col, char) => {
    if (!cwData) return;
    const expected = cwData.expected?.[row]?.[col] ?? null;
    const key = `${row}-${col}`;

    correctnessRef.current[key] =
      !!char && expected != null && char.toUpperCase() === expected;

    // UI classes (best-effort)
    const inputBox = document.querySelector(
      `[data-crossword-row="${row}"][data-crossword-col="${col}"]`
    );
    if (inputBox) {
      if (!char) {
        inputBox.classList.remove("crossword-correct", "crossword-wrong");
      } else if (correctnessRef.current[key]) {
        inputBox.classList.add("crossword-correct");
        inputBox.classList.remove("crossword-wrong");
      } else {
        inputBox.classList.add("crossword-wrong");
        inputBox.classList.remove("crossword-correct");
      }
    }

    // check scoring after update
    checkWordsAndScore();
  };


  const handleEndGame = (reason) => {
    setGameResult(reason);
    setShowPopup(true);
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  
  const handleSubmitGame = () => {
    
    checkWordsAndScore();
    
    setGameResult("submitted");
    setShowPopup(true);
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };


  if (loading) return <div className="p-8">Loading theme...</div>;
  if (error)
    return <div className="p-8 text-red-600">Failed to load theme</div>;
  if (!cwData) return <div className="p-8">Generating crossword...</div>;
  if (!theme) return <div className="p-8">Theme not available</div>;


  const bgVars = {
    "--bg-desk": `url(${theme.background_desk})`,
    "--bg-mob": `url(${theme.background_mob})`,
  };


  const finalImage =
    theme.end_game_img_popup && theme.end_game_img_popup.trim().length > 0
      ? theme.end_game_img_popup
      : theme.background_thank_you || null;
  const finalText =
    theme.end_game_text_popup && theme.end_game_text_popup.trim().length > 0
      ? theme.end_game_text_popup
      : theme.custom_text_thank_you_page || "Thank you for playing!";

  return (
    <main
      role="main"
      className="
    h-screen w-screen 
    overflow-y-auto md:overflow-hidden 
    flex items-start md:items-center justify-center 
    bg-[#fef6ec] bg-responsive
    background-size: 100% 100%;
  "
      style={bgVars}
    >
      <div className="w-[90%] max-w-[1400px] h-auto md:h-[90vh] flex flex-col overflow-visible">
        <header className="w-full top-0 z-20 py-3 px-4 relative top-[20px] md:top-0">
          <div
            className="
    grid
    grid-cols-2
    md:grid-cols-[50%_50%]
    items-center
    gap-y-3
  "
          >
            
            <div
              className="
    justify-self-start
    w-[150px] text-center rounded-[10px] px-[10px] py-[5px]
    text-[15px] font-medium bg-[#f06c60] text-white
  "
            >
              Time: {formatTime(timerSec)}
            </div>

            
            <div
              className="
    justify-self-end
    w-[150px] text-center rounded-[10px] px-[10px] py-[5px]
    text-[15px] font-medium bg-[#f06c60] text-white
  "
            >
              Points: {score}
            </div>
          </div>

          <div className="col-span-2 md:col-span-1 text-center px-2 mt-0 mb-0 md:mt-[-0] md:mb-[0] lg:mt-[-35px] lg:mb-[80px] relative top-[10px] md:top-0">
            <h1
              style={{ color: theme?.landing_page_title_color }}
              className="text-xl sm:text-2xl md:text-3xl font-extrabold leading-snug"
            >
              {theme?.landing_page_title ||
                "Solve the crossword using clues about our mission and vision"}
            </h1>

            <p className="text-gray-700 text-xs sm:text-sm md:text-base mt-1">
              {theme?.themeDescription}
            </p>
          </div>
        </header>

        <div className="min-h-screen flex flex-col items-center relative top-[100px] md:top-0">
          <div className="w-full">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
              <div className="w-full h-auto">
                {crosswordData && (
                  <Crossword
                    data={crosswordData}
                    onCellChange={(row, col, char) =>
                      handleCellChange(row, col, char)
                    }
                  />
                )}
              </div>

            
              <div className="w-full h-full flex flex-col justify-center items-center h-auto md:h-[400px]">
                <div className="w-full max-w-[500px] mx-auto text-center">
                  <h3 className=" text-left font-semibold text-xl md:text-2xl">
                    Across
                  </h3>

                  <ul className="mt-2 text-left mx-auto inline-block list-none p-0 w-[500px]">
                    {Object.keys(cwData.across)
                      .sort((a, b) => Number(a) - Number(b))
                      .map((k) => (
                        <li key={k} className="text-lg md:text-xl leading-snug">
                          <strong>{k}.</strong> {cwData.across[k].clue}
                        </li>
                      ))}
                  </ul>

                  <br />

                  <br />

                  <br />

                  <h3 className="text-left font-semibold text-xl md:text-2xl">
                    Down
                  </h3>

                  <ul className="mt-2 text-left mx-auto inline-block list-none p-0 w-[500px]">
                    {Object.keys(cwData.down)
                      .sort((a, b) => Number(a) - Number(b))
                      .map((k) => (
                        <li key={k} className="text-lg md:text-xl leading-snug">
                          <strong>{k}.</strong> {cwData.down[k].clue}
                        </li>
                      ))}
                  </ul>
                </div>

                <div className="mt-6 flex gap-3 justify-center">
                  <button
                    onClick={handleSubmitGame}
                    className="px-4 py-2 bg-green-600 text-white rounded"
                  >
                    Submit
                  </button>

                  <button
                    onClick={() => window.location.reload()}
                    className="px-4 py-2 bg-red-500 text-white rounded"
                  >
                    Restart
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

   
      {showPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-6">
            <div className="flex flex-col md:flex-row gap-4 items-center">
              {finalImage ? (
                <img
                  src={finalImage}
                  alt="end popup"
                  className="w-full md:w-1/2 object-contain rounded"
                />
              ) : null}

              <div className="flex-1 text-center md:text-left">
                <h2 className="text-2xl font-bold mb-2">{finalText}</h2>

                <p className="mt-2">
                  <strong>Score:</strong> {score}
                </p>
                <p className="mt-1">
                  <strong>Time:</strong> {formatTime(timerSec)}
                </p>

                <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center md:justify-start">
                  <button
                    onClick={() => window.location.reload()}
                    className="px-4 py-2 rounded bg-[#f06c60] text-white"
                    style={{
                      backgroundColor: theme?.button_color || undefined,
                      color: theme?.button_Textcolor || undefined,
                    }}
                  >
                    Play Again
                  </button>

                  <button
                    onClick={() => {
                      setShowPopup(false);
                      // optionally navigate elsewhere
                      // navigate('/thank-you');
                    }}
                    className="px-4 py-2 rounded border"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
