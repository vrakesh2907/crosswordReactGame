import React, { useState, useEffect, useCallback } from "react";

/**
 * FULL CUSTOM CROSSWORD ENGINE
 * 100% stable, no jump issue, complete direction lock,
 * cell coloring (correct/wrong/default), word lock, clue update.
 */

export default function Crossword({ data, onWordSolved }) {
  const [grid, setGrid] = useState([]);
  const [mode, setMode] = useState(null); // "across" | "down"
  const [selected, setSelected] = useState(null); // { row, col }

  const [acrossClues, setAcrossClues] = useState({});
  const [downClues, setDownClues] = useState({});

  useEffect(() => {
    if (!data) return;

    const { across, down } = data;

    const maxRow = findMax(across, down, "row");
    const maxCol = findMax(across, down, "col");

    let temp = Array.from({ length: maxRow }, () =>
      Array.from({ length: maxCol }, () => ({
        value: "",
        correct: null,
        readonly: false,
        isBlock: true,
      }))
    );

    // Mark cells that belong to words
    markCells(temp, across, "across");
    markCells(temp, down, "down");

    setGrid(temp);
    setAcrossClues(across);
    setDownClues(down);
  }, [data]);

  const markCells = (temp, clues, direction) => {
    Object.keys(clues).forEach((key) => {
      const item = clues[key];
      const { row, col, answer } = item;

      for (let i = 0; i < answer.length; i++) {
        if (direction === "across") {
          temp[row][col + i].isBlock = false;
        } else {
          temp[row + i][col].isBlock = false;
        }
      }
    });
  };

  /** Select cell + determine direction */
  const handleSelect = (r, c) => {
    if (grid[r][c].isBlock) return;

    let detected = detectDirection(r, c);

    setSelected({ row: r, col: c });
    setMode(detected);
  };

  const detectDirection = (r, c) => {
    const g = grid;

    // detect across word
    const left = c > 0 && !g[r][c - 1].isBlock;
    const right =
      c + 1 < g[0].length && !g[r][c + 1].isBlock;

    if (left || right) return "across";

    // detect down word
    const up = r > 0 && !g[r - 1][c].isBlock;
    const down =
      r + 1 < g.length && !g[r + 1][c].isBlock;

    if (up || down) return "down";

    return "across"; // fallback
  };

  const handleChange = (val) => {
    if (!selected || grid[selected.row][selected.col].readonly) return;
    const char = val.toUpperCase();
    const { row, col } = selected;

    updateCell(row, col, char);
    moveNext(row, col);
  };

  const updateCell = (r, c, char) => {
    const answer = findExpectedLetter(r, c);

    setGrid((g) => {
      const newG = g.map((row) => row.map((cell) => ({ ...cell })));
      newG[r][c].value = char;

      if (!char) newG[r][c].correct = null;
      else newG[r][c].correct = char === answer;

      return newG;
    });

    checkWordSolved(r, c);
  };

  const findExpectedLetter = (r, c) => {
    const { across, down } = data;

    for (const key in across) {
      const item = across[key];
      for (let i = 0; i < item.answer.length; i++) {
        if (item.row === r && item.col + i === c) {
          return item.answer[i].toUpperCase();
        }
      }
    }

    for (const key in down) {
      const item = down[key];
      for (let i = 0; i < item.answer.length; i++) {
        if (item.row + i === r && item.col === c) {
          return item.answer[i].toUpperCase();
        }
      }
    }

    return "";
  };

  const moveNext = (r, c) => {
    if (mode === "across") {
      let nextC = c + 1;
      while (nextC < grid[0].length && grid[r][nextC].isBlock)
        nextC++;

      if (nextC < grid[0].length) {
        setSelected({ row: r, col: nextC });
        return;
      }
    }

    if (mode === "down") {
      let nextR = r + 1;
      while (nextR < grid.length && grid[nextR][c].isBlock)
        nextR++;

      if (nextR < grid.length) {
        setSelected({ row: nextR, col: c });
        return;
      }
    }
  };

  const checkWordSolved = (r, c) => {
    const acrossKey = findAcrossKey(r, c);
    const downKey = findDownKey(r, c);

    if (acrossKey) checkDirectionSolved(acrossKey, "across");
    if (downKey) checkDirectionSolved(downKey, "down");
  };

  const findAcrossKey = (r, c) => {
    for (const key in acrossClues) {
      const item = acrossClues[key];
      if (r === item.row && c >= item.col && c < item.col + item.answer.length)
        return key;
    }
    return null;
  };

  const findDownKey = (r, c) => {
    for (const key in downClues) {
      const item = downClues[key];
      if (c === item.col && r >= item.row && r < item.row + item.answer.length)
        return key;
    }
    return null;
  };

  const checkDirectionSolved = (key, type) => {
    const item = type === "across" ? acrossClues[key] : downClues[key];
    const len = item.answer.length;

    let correct = true;

    for (let i = 0; i < len; i++) {
      const r = type === "across" ? item.row : item.row + i;
      const c = type === "across" ? item.col + i : item.col;

      if (grid[r][c].value !== item.answer[i].toUpperCase()) {
        correct = false;
        break;
      }
    }

    if (!correct) return;

    // Word solved → lock all cells
    lockWord(item, type);

    // update clue
    if (type === "across") {
      acrossClues[key].clue += ` — ${item.answer}`;
      setAcrossClues({ ...acrossClues });
    } else {
      downClues[key].clue += ` — ${item.answer}`;
      setDownClues({ ...downClues });
    }

    if (onWordSolved) onWordSolved();
  };

  const lockWord = (item, type) => {
    const len = item.answer.length;

    setGrid((g) => {
      const newG = g.map((row) => row.map((cell) => ({ ...cell })));

      for (let i = 0; i < len; i++) {
        const r = type === "across" ? item.row : item.row + i;
        const c = type === "across" ? item.col + i : item.col;

        newG[r][c].readonly = true;
        newG[r][c].correct = true;
      }

      return newG;
    });
  };

  return (
    <div className="flex gap-6 p-4 select-none">
      {/* GRID */}
      <div>
        <table className="border-collapse">
          <tbody>
            {grid.map((row, r) => (
              <tr key={r}>
                {row.map((cell, c) => {
                  const highlight =
                    selected && selected.row === r && selected.col === c;

                  let bg = "bg-white";
                  if (cell.correct === true) bg = "bg-green-500 text-white";
                  else if (cell.correct === false) bg = "bg-red-500 text-white";

                  return (
                    <td
                      key={c}
                      className="border w-10 h-10"
                      onClick={() => handleSelect(r, c)}
                    >
                      {!cell.isBlock ? (
                        <input
                          maxLength={1}
                          value={cell.value}
                          readOnly={cell.readonly}
                          onChange={(e) => handleChange(e.target.value)}
                          className={`w-full h-full text-center font-bold outline-none ${bg}`}
                          autoFocus={highlight}
                        />
                      ) : (
                        <div className="w-full h-full bg-black" />
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* CLUES */}
      <div className="w-64 text-sm">
        <h3 className="font-semibold text-lg mb-2">Across</h3>
        <ul className="space-y-1">
          {Object.keys(acrossClues).map((k) => (
            <li key={k}>
              <strong>{k}.</strong> {acrossClues[k].clue}
            </li>
          ))}
        </ul>

        <h3 className="font-semibold text-lg mt-4 mb-2">Down</h3>
        <ul className="space-y-1">
          {Object.keys(downClues).map((k) => (
            <li key={k}>
              <strong>{k}.</strong> {downClues[k].clue}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function findMax(across, down, type) {
  let max = 0;
  const check = (obj) => {
    Object.values(obj).forEach((item) => {
      const pos = type === "row" ? item.row : item.col;
      const total = pos + (item.answer?.length || 0);
      if (total > max) max = total;
    });
  };
  check(across);
  check(down);
  return max + 1;
}
