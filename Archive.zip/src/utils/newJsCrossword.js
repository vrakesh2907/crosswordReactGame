/* eslint-disable */
import React, { useState, useEffect, useRef } from "react";

export default function CustomCrossword({
  gridData,
  across,
  down,
  onScore,
  onWordCompleted, // NEW: callback to parent when a word is completed
}) {
  const [grid, setGrid] = useState([]);
  const [status, setStatus] = useState({});
  const [activeClue, setActiveClue] = useState(null);

  const inputsRef = useRef({});
  const clueCellsRef = useRef({});
  const clueNumbersRef = useRef({});
  const frozenWordsRef = useRef({}); // NEW: "A1": true, "D4": true
  const completedAnswersRef = useRef({}); // NEW: "1": "GOAL"

  /** INIT GRID **/
  useEffect(() => {
    const cloned = gridData.map((row) =>
      row.map((cell) => ({
        letter: cell || "",
        user: "",
        block: cell === null,
      }))
    );

    setGrid(cloned);
    inputsRef.current = {};
    clueCellsRef.current = {};
    clueNumbersRef.current = {};
    frozenWordsRef.current = {};
    completedAnswersRef.current = {};
    setStatus({});
    setActiveClue(null);
  }, [gridData]);

  /** BUILD CLUE CELLS **/
  useEffect(() => {
    if (!grid || grid.length === 0) return;

    const newClueCells = {};
    const newNumbers = {};

    // ACROSS
    Object.entries(across).forEach(([num, d]) => {
      const cells = [];
      let r = d.row;
      let c = d.col;

      for (let i = 0; i < d.answer.length; i++) {
        if (!grid[r] || !grid[r][c] || grid[r][c].block) break;
        cells.push({ r, c });
        c++;
      }

      newClueCells[`A${num}`] = cells;
      if (cells.length > 0) {
        newNumbers[`${cells[0].r}-${cells[0].c}`] = num;
      }
    });

    // DOWN
    Object.entries(down).forEach(([num, d]) => {
      const cells = [];
      let r = d.row;
      let c = d.col;

      for (let i = 0; i < d.answer.length; i++) {
        if (!grid[r] || !grid[r][c] || grid[r][c].block) break;
        cells.push({ r, c });
        r++;
      }

      newClueCells[`D${num}`] = cells;
      if (cells.length > 0 && !newNumbers[`${cells[0].r}-${cells[0].c}`]) {
        newNumbers[`${cells[0].r}-${cells[0].c}`] = num;
      }
    });

    clueCellsRef.current = newClueCells;
    clueNumbersRef.current = newNumbers;
  }, [grid]);

  /** Find clue(s) a cell belongs to **/
  const findCluesForCell = (r, c) => {
    const result = [];

    for (const key of Object.keys(clueCellsRef.current)) {
      const arr = clueCellsRef.current[key];
      if (arr.some((p) => p.r === r && p.c === c)) {
        const direction = key.startsWith("A") ? "across" : "down";
        const num = key.slice(1);
        result.push({ key, num, direction });
      }
    }
    return result;
  };

  /** Detect new clue selection **/
  const handleFocus = (r, c) => {
    const candidates = findCluesForCell(r, c);
    if (!candidates.length) return;

    // If clicked belongs to the active clue → keep it
    if (activeClue) {
      const activeKey =
        activeClue.direction === "across"
          ? `A${activeClue.num}`
          : `D${activeClue.num}`;

      const belongs = clueCellsRef.current[activeKey]?.some(
        (p) => p.r === r && p.c === c
      );

      if (belongs) return;
    }

    // Otherwise → new clue selected
    const acrossCandidate = candidates.find((x) => x.direction === "across");
    const chosen = acrossCandidate || candidates[0];

    setActiveClue({ num: chosen.num, direction: chosen.direction });
  };

  /** Move cursor helpers **/
  const focusCell = (r, c) => {
    const el = inputsRef.current[`${r}-${c}`];
    if (!el) return;
    setTimeout(() => el.focus(), 0);
  };

const moveNext = (r, c) => {
  if (!activeClue) return;

  const clueKey =
    activeClue.direction === "across"
      ? `A${activeClue.num}`
      : `D${activeClue.num}`;

  const cells = clueCellsRef.current[clueKey];
  if (!cells) return;

  const idx = cells.findIndex((p) => p.r === r && p.c === c);

  // Try next cells until a non-frozen editable cell is found
  for (let i = idx + 1; i < cells.length; i++) {
    const next = cells[i];
    const cellKey = `${next.r}-${next.c}`;

    const isFrozen = findCluesForCell(next.r, next.c).some((cinfo) =>
      frozenWordsRef.current[
        `${cinfo.direction === "across" ? "A" : "D"}${cinfo.num}`
      ]
    );

    if (!isFrozen) {
      focusCell(next.r, next.c);
      return;
    }
  }

  // No editable cell found → do not move
};


const movePrev = (r, c) => {
  if (!activeClue) return;

  const clueKey =
    activeClue.direction === "across"
      ? `A${activeClue.num}`
      : `D${activeClue.num}`;

  const cells = clueCellsRef.current[clueKey];
  if (!cells) return;

  const idx = cells.findIndex((p) => p.r === r && p.c === c);

  for (let i = idx - 1; i >= 0; i--) {
    const prev = cells[i];
    const cellKey = `${prev.r}-${prev.c}`;

    const isFrozen = findCluesForCell(prev.r, prev.c).some((cinfo) =>
      frozenWordsRef.current[
        `${cinfo.direction === "across" ? "A" : "D"}${cinfo.num}`
      ]
    );

    if (!isFrozen) {
      focusCell(prev.r, prev.c);
      return;
    }
  }
};


  /** Freeze word if completed **/
  const evaluateClueCompletion = (num, direction) => {
    const key = direction === "across" ? `A${num}` : `D${num}`;
    const cells = clueCellsRef.current[key] || [];
    if (!cells.length) return;

    // check if all are correct
    const done = cells.every((p) => status[`${p.r}-${p.c}`] === "correct");

    if (done && !frozenWordsRef.current[key]) {
      frozenWordsRef.current[key] = true;

      // reveal clue answer in parent
      const fullAnswer =
        direction === "across" ? across[num]?.answer : down[num]?.answer;

      completedAnswersRef.current[num] = fullAnswer;

      if (onWordCompleted) {
        onWordCompleted(num, fullAnswer);
      }
    }
  };

  /** Input change **/
  const handleChange = (r, c, value) => {
    const val = value.toUpperCase().slice(-1);

    const correct = grid[r][c].letter;

    setGrid((prev) => {
      const copy = prev.map((row) => row.map((obj) => ({ ...obj })));
      copy[r][c].user = val;
      return copy;
    });

    setStatus((prev) => ({
      ...prev,
      [`${r}-${c}`]:
        val === ""
          ? "blank"
          : val === correct
          ? "correct"
          : "wrong",
    }));

    // After every input, check if entire word is completed
    if (activeClue && val !== "") {
   //   evaluateClueCompletion(activeClue.num, activeClue.direction);
      moveNext(r, c);
    }
  };

  /** Key handling **/
  const handleKeyDown = (e, r, c) => {
    const key = `${r}-${c}`;

    // If this cell belongs to a frozen word → block editing
    const clues = findCluesForCell(r, c);
    const frozen = clues.some((c) =>
      frozenWordsRef.current[`${c.direction === "across" ? "A" : "D"}${c.num}`]
    );
    if (frozen) {
      e.preventDefault();
      return;
    }

    if (e.key === "Backspace") {
      setTimeout(() => {
        if (!inputsRef.current[key]?.value) {
          movePrev(r, c);
        }
      }, 0);
    }

    // direction locked arrows
    if (activeClue) {
      if (activeClue.direction === "across") {
        if (e.key === "ArrowRight") {
          e.preventDefault();
          moveNext(r, c);
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          movePrev(r, c);
        }
      } else {
        if (e.key === "ArrowDown") {
          e.preventDefault();
          moveNext(r, c);
        }
        if (e.key === "ArrowUp") {
          e.preventDefault();
          movePrev(r, c);
        }
      }
    }
  };

  /** Calculate Score **/
  useEffect(() => {
    const correctCount = Object.values(status).filter((x) => x === "correct").length;
    onScore(correctCount);
  }, [status]);


  useEffect(() => {
  if (!activeClue) return;

  const key =
    activeClue.direction === "across"
      ? `A${activeClue.num}`
      : `D${activeClue.num}`;

  const cells = clueCellsRef.current[key];
  if (!cells || !cells.length) return;

  // check all correct after status is fully updated
  const done = cells.every(
    (p) => status[`${p.r}-${p.c}`] === "correct"
  );

  if (done && !frozenWordsRef.current[key]) {
    frozenWordsRef.current[key] = true;

    const answer =
      activeClue.direction === "across"
        ? across[activeClue.num].answer
        : down[activeClue.num].answer;

    completedAnswersRef.current[activeClue.num] = answer;

    // notify parent
    onWordCompleted?.(activeClue.num, answer);
  }
}, [status]);


  const clueNumbers = clueNumbersRef.current;

  return (
    <div className="flex flex-col items-center">
      <div
        className="grid"
        style={{
          gridTemplateColumns: `repeat(${grid[0]?.length || 0}, 44px)`,
          gap: "2px",
        }}
      >
        {grid.map((row, r) =>
          row.map((cell, c) => {
            if (cell.block) {
              return <div key={`${r}-${c}`} className="w-[44px] h-[44px] bg-black" />;
            }

            const st = status[`${r}-${c}`];
            const key = `${r}-${c}`;

            // check if this cell is frozen
            const belongsToFrozen = findCluesForCell(r, c).some((fc) =>
              frozenWordsRef.current[
                `${fc.direction === "across" ? "A" : "D"}${fc.num}`
              ]
            );

            const bg =
              belongsToFrozen || st === "correct"
                ? "#4CAF50"
                : st === "wrong"
                ? "#F44336"
                : "white";

            return (
              <div
                key={`${r}-${c}`}
                className="relative w-[44px] h-[44px] border"
                style={{ background: bg }}
              >
                {clueNumbers[`${r}-${c}`] && (
                  <div
                    className="absolute text-[9px] font-bold"
                    style={{ top: 2, left: 4 }}
                  >
                    {clueNumbers[`${r}-${c}`]}
                  </div>
                )}

                <input
                  disabled={belongsToFrozen} // FREEZE COMPLETED WORDS
                  ref={(el) => (inputsRef.current[key] = el)}
                  maxLength={1}
                  value={cell.user}
                  onFocus={() => handleFocus(r, c)}
                  onClick={() => handleFocus(r, c)}
                  onChange={(e) => handleChange(r, c, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(e, r, c)}
                  className="absolute inset-0 w-full h-full text-center font-bold text-xl outline-none bg-transparent"
                  style={{ textTransform: "uppercase" }}
                />
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
