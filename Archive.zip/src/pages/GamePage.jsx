/* eslint-disable */
import React, { useContext, useEffect, useMemo, useState } from "react";
import { ThemeContext } from "../contexts/ThemeContext";
import { ParamContext } from "../contexts/ParamContext";
import useParamNavigation from "../hooks/useParamNavigation";
import { layoutToCrossword } from "../utils/layoutAdapter";
import CustomCrossword from "../utils/newJsCrossword";

function parseTimerString(str) {
  if (!str) return 0;
  const parts = str.split(":");
  if (parts.length === 2) {
    return (parseInt(parts[0]) || 0) * 60 + (parseInt(parts[1]) || 0);
  }
  const minutes = parseInt(str, 10);
  return isNaN(minutes) ? 0 : minutes * 60;
}

export default function SmartCrosswordPage() {
  const { theme, session, loading, error } = useContext(ThemeContext);
  const { otp, role } = useContext(ParamContext);
  const navigateWithParams = useParamNavigation();

  const [score, setScore] = useState(0);
  const [timerSec, setTimerSec] = useState(0);
  const [showPopup, setShowPopup] = useState(false);
  const [completedAnswers, setCompletedAnswers] = useState({});
  const [completedWords, setCompletedWords] = useState({});
  const [progress, setProgress] = useState(0);

  // -------------------------
  // Load RAW puzzle words
  // -------------------------
  const rawWordsArray = useMemo(() => {
    if (!theme) return null;

    if (Array.isArray(theme.questions_and_answers))
      return theme.questions_and_answers;

    if (Array.isArray(theme.words)) return theme.words;

    if (Array.isArray(theme.questions)) return theme.questions;

    for (const key of Object.keys(theme)) {
      if (
        Array.isArray(theme[key]) &&
        theme[key]?.length > 0 &&
        (theme[key][0].question || theme[key][0].answer)
      ) {
        return theme[key];
      }
    }

    return null;
  }, [theme]);

  // -------------------------
  // Build crossword puzzle
  // -------------------------
  const puzzle = useMemo(() => {
    if (!rawWordsArray) return null;
    try {
      return layoutToCrossword(rawWordsArray);
    } catch (e) {
      console.error("layoutToCrossword error", e);
      return null;
    }
  }, [rawWordsArray]);

  // -------------------------
  // Score calculation
  // -------------------------
  useEffect(() => {
    if (!theme) return;
    const wordCount = Object.keys(completedWords).length;
    const pointsPerWord = Number(theme.points) || 5;
    setScore(wordCount * pointsPerWord);
  }, [completedWords, theme]);

  // -------------------------
  // Timer initialization
  // -------------------------
  useEffect(() => {
    if (!theme) return;

    if (theme.use_timeout === true || theme.use_timeout === "true") {
      setTimerSec(parseTimerString(theme.timer));
    } else {
      setTimerSec(0);
    }
  }, [theme]);

  // -------------------------
  // Timer running
  // -------------------------
  useEffect(() => {
    if (!theme) return;

    let tid;

    if (theme.use_timeout === true || theme.use_timeout === "true") {
      // countdown
      tid = setInterval(() => {
        setTimerSec((s) => {
          if (s <= 1) {
            clearInterval(tid);
            setShowPopup(true);
            return 0;
          }
          return s - 1;
        });
      }, 1000);
    } else {
      // count-up
      tid = setInterval(() => {
        setTimerSec((s) => s + 1);
      }, 1000);
    }

    return () => clearInterval(tid);
  }, [theme]);

  // -------------------------
  // Progress bar calculation
  // -------------------------
  useEffect(() => {
    if (!puzzle) return;

    const total =
      Object.keys(puzzle.across || {}).length +
      Object.keys(puzzle.down || {}).length;

    const solved = Object.keys(completedWords).length;

    if (total > 0) {
      setProgress((solved / total) * 100);
    }
  }, [completedWords, puzzle]);

  const formatTime = (sec) => {
    const m = Math.floor(sec / 60).toString().padStart(2, "0");
    const s = (sec % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  const bgVars = {
    "--bg-desk": theme?.background_desk
      ? `url(${theme.background_desk})`
      : undefined,
    "--bg-mob": theme?.background_mob
      ? `url(${theme.background_mob})`
      : undefined,
  };

  const finalImage =
    theme?.end_game_img_popup?.trim()
      ? theme.end_game_img_popup
      : theme?.background_thank_you;

  const finalText =
    theme?.end_game_text_popup?.trim()
      ? theme.end_game_text_popup
      : theme?.custom_text_thank_you_page;

  // -------------------------
  // UI STARTS HERE
  // -------------------------

  return (
    <main
      role="main"
      className="min-h-screen w-screen overflow-y-auto flex items-start md:items-center justify-center bg-[#fef6ec]"
      style={bgVars}
    >
      <div className="w-[90%] max-w-[1400px] flex flex-col">
        {/* LOADING / ERROR */}
        {loading && <div className="p-8">Loading theme...</div>}
        {error && <div className="p-8 text-red-500">Failed to load theme</div>}
        {!rawWordsArray && !loading && (
          <div className="p-8">Puzzle data missing in theme</div>
        )}

        {/* Only render game if puzzle is valid */}
        {puzzle && puzzle.grid && (
          <>
            {/* -------- TOP BAR -------- */}
            <header className="w-full py-3 px-4">
              <div className="grid grid-cols-2 items-center gap-2">
                <div className="bg-[#f06c60] text-white px-3 py-1 rounded text-center">
                  Time: {formatTime(timerSec)}
                </div>
                <div className="bg-[#f06c60] text-white px-3 py-1 rounded text-center">
                  Points: {score}
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mt-4 w-full">
                <div className="bg-gray-300 h-3 rounded-full">
                  <div
                    className="bg-green-600 h-3 rounded-full transition-all duration-500"
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>
                <div className="text-center text-sm mt-1">
                  {Math.round(progress)}% Completed
                </div>
              </div>

              <div className="text-center mt-3">
                <h1
                  className="text-xl sm:text-2xl md:text-3xl font-extrabold"
                  style={{ color: theme?.landing_page_title_color || "#000" }}
                >
                  {theme?.landing_page_title || "Solve the puzzle"}
                </h1>
                <p className="text-gray-700 mt-1 text-sm">
                  {theme?.themeDescription || ""}
                </p>
              </div>
            </header>

            {/* -------- GAME AREA -------- */}
            <div className="flex flex-col md:flex-row gap-6 mt-8">
              {/* Crossword */}
              <div className="flex-1 flex justify-center">
                <CustomCrossword
                  gridData={puzzle.grid}
                  across={puzzle.across}
                  down={puzzle.down}
                  onScore={() => {}}
                  onWordCompleted={(num, ans) => {
                    setCompletedWords((prev) => ({ ...prev, [num]: true }));
                    setCompletedAnswers((prev) => ({
                      ...prev,
                      [num]: ans,
                    }));
                  }}
                />
              </div>

              {/* Clues */}
              <div className="flex-1 text-left max-w-[500px] mx-auto">
                <h3 className="text-2xl font-semibold">Across</h3>
                <ul className="mt-2 space-y-1">
                  {Object.entries(puzzle.across).map(([num, d]) => (
                    <li key={num}>
                      <strong>{num}.</strong> {d.clue}
                      {completedAnswers[num] && (
                        <span className="text-green-700 ml-2">
                          — {completedAnswers[num]}
                        </span>
                      )}
                    </li>
                  ))}
                </ul>

                <h3 className="text-2xl font-semibold mt-8">Down</h3>
                <ul className="mt-2 space-y-1">
                  {Object.entries(puzzle.down).map(([num, d]) => (
                    <li key={num}>
                      <strong>{num}.</strong> {d.clue}
                      {completedAnswers[num] && (
                        <span className="text-green-700 ml-2">
                          — {completedAnswers[num]}
                        </span>
                      )}
                    </li>
                  ))}
                </ul>

                <div className="mt-6 flex gap-3">
                  <button
                    onClick={() => setShowPopup(true)}
                    className="px-4 py-2 bg-green-600 text-white rounded"
                  >
                    Submit
                  </button>

                  <button
                    onClick={() => window.location.reload()}
                    className="px-4 py-2 bg-red-500 text-white rounded"
                  >
                    Restart
                  </button>
                </div>
              </div>
            </div>
          </>
        )}
      </div>

      {/* -------- POPUP -------- */}
      {showPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-6">
            <div className="flex flex-col md:flex-row gap-4 items-center">
              {finalImage && (
                <img
                  src={finalImage}
                  className="w-full md:w-1/2 object-contain rounded"
                />
              )}

              <div className="flex-1 text-center md:text-left">
                <h2 className="text-2xl font-bold mb-2">{finalText}</h2>

                <p className="mt-2">
                  <strong>Score:</strong> {score}
                </p>
                <p className="mt-1">
                  <strong>Time:</strong> {formatTime(timerSec)}
                </p>

                <div className="mt-6 flex gap-3 justify-center md:justify-start">
                  <button
                    onClick={() => window.location.reload()}
                    className="px-4 py-2 bg-[#f06c60] text-white rounded"
                  >
                    Play Again
                  </button>

                  <button
                    onClick={() => setShowPopup(false)}
                    className="px-4 py-2 border rounded"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
